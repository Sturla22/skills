# Compatibility Notes

## Canonical source of truth

This repo treats `.agents/` as canonical.

- `.agents/agents/*.toml` defines the shared role model
- `.agents/skills/<skill-name>/SKILL.md` defines shared skills
- `.agents/project/CLAUDE.md` defines Claude project instructions

Run `python3 scripts/sync_agent_layouts.py` after editing canonical agent or skill files.

## Claude Code

Generated Claude Code files live in:

- `.claude/CLAUDE.md`
- `.claude/skills/<skill-name>/SKILL.md`
- `.claude/agents/*.md`

Claude-specific discovery stays native, but the content comes from `.agents/`.

## GitHub Copilot

This repo uses GitHub Copilot customization layers:

- `.github/copilot-instructions.md` for repository-wide instructions
- `.github/instructions/*.instructions.md` for path-specific instructions
- `.github/agents/*.agent.md` for custom agents
- `AGENTS.md` as a repo-level agent instruction file

The custom agent files under `.github/agents/` are generated from `.agents/agents/*.toml`.

## OpenAI Codex

This repo uses Codex-native project layers:

- `AGENTS.md` for root project instructions
- `.agents/skills/<skill-name>/SKILL.md` for shared repo skills
- `.codex/config.toml` for project-scoped Codex configuration
- `.codex/agents/*.toml` for custom Codex subagents

The custom agent files under `.codex/agents/` are generated from `.agents/agents/*.toml`.

## Why all three are present

The goal is not to make one giant shared prompt. Instead:

- `AGENTS.md` stays short and durable
- `.agents/` is the portable shared layer
- `.claude/` stays compatible with Claude Code discovery
- `.github/agents/` stays compatible with Copilot custom agents
- `.codex/agents/` stays compatible with Codex subagents
- `.github/instructions/` adds path-specific guidance that does not belong in shared role files

## Suggested adaptation strategy

- Start by customizing `AGENTS.md`, `.agents/project/CLAUDE.md`, and `.github/copilot-instructions.md`.
- Then tune `.codex/config.toml`.
- Only after that, tune skills and path-specific instructions to match your build, test, and firmware boundaries.
- Use `python3 scripts/sync_agent_layouts.py --check` in CI to catch drift.
